package com.prince.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Bg = Color(0xFF070B12)
private val Panel = Color(0xFF111A27)
private val Cyan = Color(0xFF35D9F5)
private val Orange = Color(0xFFFF9C45)
private val White = Color(0xFFEAF4FF)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent {
            JarvisApp(
                startListening = { onListenResult = it; startListening() },
                speak = { speakText(it) }
            )
        }
    }

    private var onListenResult: ((String) -> Unit)? = null

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingMicStart = true
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        val recognizer = speechRecognizer ?: return
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { runOnUiThread { micStatus = "Voice input stopped (error $error)" } }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!words.isNullOrBlank()) onListenResult?.invoke(words)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        micStatus = "Listening…"
        recognizer.startListening(intent)
    }

    private var pendingMicStart = false
    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && pendingMicStart) { pendingMicStart = false; startListening() }
        else { pendingMicStart = false; micStatus = "Microphone permission denied" }
    }

    private var micStatus by mutableStateOf("Ready")

    private fun speakText(text: String) {
        if (speechReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-reply")
    }

    override fun onInit(status: Int) {
        speechReady = status == TextToSpeech.SUCCESS
        if (speechReady) tts?.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisApp(startListening: ((String) -> Unit) -> Unit, speak: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis_settings", android.content.Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf(prefs.getString("gemini_api_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash") }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready • Configure your Gemini API key in Settings") }
    val messages = remember { mutableStateListOf(ChatMessage("Hello! Main JARVIS hoon. Settings mein apni Gemini API key save karke mujhse baat shuru kar sakte hain.", false)) }
    val scope = rememberCoroutineScope()
    val client = remember { OkHttpClient.Builder().callTimeout(java.time.Duration.ofSeconds(60)).build() }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Orange, background = Bg, surface = Panel,
        onPrimary = Bg, onBackground = White, onSurface = White
    )) {
        if (showSettings) {
            SettingsScreen(
                apiKey = apiKey, onApiKey = { apiKey = it },
                model = model, onModel = { model = it },
                onSave = {
                    prefs.edit().putString("gemini_api_key", apiKey.trim()).putString("model", model.trim()).apply()
                    showSettings = false
                    status = if (apiKey.isBlank()) "API key missing" else "Settings saved"
                },
                onBack = { showSettings = false }
            )
        } else {
            Column(
                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101E30), Bg))).padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("JARVIS", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Cyan)
                        Text("PERSONAL AI ASSISTANT", fontSize = 10.sp, letterSpacing = 2.sp, color = Orange)
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = White)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.size(142.dp).background(Color(0x2235D9F5), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(108.dp).background(Color(0x3335D9F5), CircleShape), contentAlignment = Alignment.Center) {
                            Text("J", fontSize = 64.sp, fontWeight = FontWeight.Light, color = Cyan)
                        }
                    }
                }
                Text(status, color = Color(0xFF9EB4CA), fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    items(messages) { msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                            Column(
                                Modifier.widthIn(max = 320.dp).background(
                                    if (msg.fromUser) Color(0xFF12384A) else Panel,
                                    RoundedCornerShape(16.dp)
                                ).padding(12.dp)
                            ) {
                                Text(if (msg.fromUser) "YOU" else "JARVIS", color = if (msg.fromUser) Cyan else Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp))
                                Text(msg.text, color = White, fontSize = 15.sp)
                                if (!msg.fromUser) {
                                    TextButton(onClick = { speak(msg.text) }, contentPadding = PaddingValues(0.dp)) {
                                        Icon(Icons.Default.VolumeUp, contentDescription = "Speak", modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp)); Text("Speak")
                                    }
                                }
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = { startListening { heard -> input = heard; status = "Voice captured" } }) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice input", tint = Cyan)
                    }
                    BasicTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f).background(Panel, RoundedCornerShape(14.dp)).padding(14.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp),
                        decorationBox = { inner ->
                            Box {
                                if (input.isBlank()) Text("Type or tap mic…", color = Color.Gray)
                                inner()
                            }
                        }
                    )
                    IconButton(enabled = !busy, onClick = {
                        val prompt = input.trim()
                        if (prompt.isNotEmpty()) {
                            input = ""
                            messages.add(ChatMessage(prompt, true))
                            if (apiKey.isBlank()) {
                                messages.add(ChatMessage("Pehle Settings mein Gemini API key save karein.", false))
                                showSettings = true
                            } else {
                                busy = true; status = "Thinking…"
                                scope.launch {
                                    val answer = withContext(Dispatchers.IO) { askGemini(client, apiKey, model, prompt, messages.filter { !it.fromUser || it.text != prompt }.takeLast(12)) }
                                    messages.add(ChatMessage(answer, false))
                                    status = if (answer.startsWith("Connection error:") || answer.startsWith("API error:")) "Needs attention" else "Ready"
                                    busy = false
                                }
                            }
                        }
                    }) {
                        if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Default.Send, contentDescription = "Send", tint = Cyan)
                    }
                }
                Text("Text chat + Android speech input/output • Live voice and background wake word are not enabled in this starter.", color = Color(0xFF6F8498), fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

private fun askGemini(
    client: OkHttpClient,
    apiKey: String,
    model: String,
    prompt: String,
    history: List<ChatMessage>
): String {
    return try {
        val contents = JSONArray()
        history.forEach { item ->
            contents.put(JSONObject().put("role", if (item.fromUser) "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", item.text))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put(
                "text", "You are JARVIS, a helpful Indian AI assistant created by Prince. Speak naturally in Hindi or Hinglish when appropriate, use respectful and concise language, and never claim to control the phone unless a real tool completed the action. You are software, not a human."
            ))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.8).put("maxOutputTokens", 1200))
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
            .addHeader("x-goog-api-key", apiKey.trim())
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody())
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = try { JSONObject(raw).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                "API error: ${response.code}. ${message ?: "Check API key, model name, network, and API access."}"
            } else {
                val json = JSONObject(raw)
                json.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                    ?.optString("text")?.takeIf { it.isNotBlank() }
                    ?: "Response empty hai. Please dobara try karein."
            }
        }
    } catch (e: Exception) {
        "Connection error: ${e.message ?: "Unknown network or API error"}"
    }
}

@Composable
private fun SettingsScreen(
    apiKey: String, onApiKey: (String) -> Unit,
    model: String, onModel: (String) -> Unit,
    onSave: () -> Unit, onBack: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("JARVIS SETTINGS", color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Gemini API configuration", color = White, fontSize = 18.sp)
        Text("API key ko private rakhein. Is starter mein key app ke private preferences mein rakhi jaati hai; production release ke liye stronger secret-handling/backend architecture review karein.", color = Color(0xFF9EB4CA), fontSize = 12.sp)
        OutlinedTextField(
            value = apiKey, onValueChange = onApiKey, label = { Text("Gemini API key") },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White)
        )
        OutlinedTextField(
            value = model, onValueChange = onModel, label = { Text("Text model ID") },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = White, unfocusedTextColor = White)
        )
        Text("Default model ID is a configurable starting value, not a guarantee of account access. If it returns a model-not-found error, enter a model available to your API key.", color = Color(0xFF9EB4CA), fontSize = 12.sp)
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Save settings") }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}
